/* ============================================================
   KRONIA — shared UI primitives + injected stylesheet
   ============================================================ */
(function injectStyles() {
  if (document.getElementById("kronia-styles")) return;
  const css = `
  .phone {
    width: 392px; padding: 12px;
    border-radius: 54px;
    background: linear-gradient(155deg,#1c2738,#070d18 45%,#020610);
    box-shadow: 0 0 0 1.5px rgba(80,140,220,0.18),
                0 30px 70px -20px rgba(0,0,0,0.85),
                0 0 90px -30px rgba(26,127,232,0.5);
    position: relative;
  }
  .phone::after{ content:""; position:absolute; inset:0; border-radius:54px; pointer-events:none;
    box-shadow: inset 0 1px 1px rgba(255,255,255,0.10); }
  .phone-screen {
    position: relative; width: 100%; height: 812px;
    border-radius: 43px; overflow: hidden;
    background: linear-gradient(180deg,#02091a,#010714 55%);
    isolation: isolate;
  }
  .phone-screen::before{
    content:""; position:absolute; inset:0; pointer-events:none; z-index:0;
    background-image:
      linear-gradient(rgba(40,110,200,0.05) 1px, transparent 1px),
      linear-gradient(90deg, rgba(40,110,200,0.05) 1px, transparent 1px);
    background-size: 30px 30px;
    mask-image: radial-gradient(130% 80% at 50% 0%, #000 30%, transparent 80%);
  }
  .island{ position:absolute; top:11px; left:50%; transform:translateX(-50%);
    width:120px; height:33px; background:#000; border-radius:20px; z-index:60;
    box-shadow: inset 0 0 0 1px rgba(60,90,130,0.25); }
  .statusbar{ position:absolute; top:0; left:0; right:0; height:52px; z-index:55;
    display:flex; align-items:center; justify-content:space-between;
    padding:18px 28px 0; font-family:var(--display); font-weight:600; font-size:14px;
    color:#dceaff; }
  .statusbar .sb-r{ display:flex; align-items:center; gap:7px; }
  .sb-bars{ display:flex; align-items:flex-end; gap:2px; height:11px; }
  .sb-bars i{ width:3px; background:#dceaff; border-radius:1px; display:block; }
  .sb-batt{ width:23px; height:12px; border:1.3px solid rgba(220,234,255,0.7); border-radius:3px; position:relative; padding:1.5px; }
  .sb-batt::after{ content:""; position:absolute; right:-3px; top:3.5px; width:2px; height:5px; background:rgba(220,234,255,0.7); border-radius:0 1px 1px 0; }
  .sb-batt i{ display:block; height:100%; width:80%; background:#dceaff; border-radius:1px; }

  .screen-scroll{ position:absolute; inset:0; z-index:10; overflow-y:auto; overflow-x:hidden;
    padding:54px 0 100px; -webkit-overflow-scrolling:touch; scrollbar-width:none; }
  .screen-scroll::-webkit-scrollbar{ display:none; }
  .pad{ padding-left:20px; padding-right:20px; }

  /* bottom nav */
  .bnav{ position:absolute; left:0; right:0; bottom:0; height:82px; z-index:50;
    display:flex; align-items:stretch; padding:0 6px 14px;
    background:linear-gradient(180deg, rgba(3,9,20,0), rgba(2,6,14,0.94) 40%, #020610);
    backdrop-filter: blur(8px); border-top:1px solid rgba(40,110,200,0.16); }
  .bnav-item{ flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center;
    gap:5px; color:var(--muted-d); cursor:pointer; position:relative; padding-top:11px;
    transition:color .18s ease; background:none; border:none; font-family:var(--body); }
  .bnav-item span{ font-size:10px; font-weight:600; letter-spacing:0.02em; }
  .bnav-item .ind{ position:absolute; top:0; width:26px; height:3px; border-radius:0 0 4px 4px;
    background:linear-gradient(90deg,var(--blue),var(--cyan)); opacity:0;
    box-shadow:0 0 12px 1px rgba(0,194,255,0.7); transition:opacity .2s; }
  .bnav-item.on{ color:var(--cyan); }
  .bnav-item.on .ind{ opacity:1; }
  .bnav-item.on svg{ filter:drop-shadow(0 0 7px rgba(0,194,255,0.55)); }

  /* cards */
  .card{ position:relative; background:var(--card); border:1px solid var(--line); border-radius:16px; padding:16px; overflow:hidden; box-shadow:var(--shadow); }
  .card.glow{ box-shadow:var(--shadow); }
  .card.glow::before{ content:""; position:absolute; inset:0; pointer-events:none; border-radius:16px;
    background:radial-gradient(130% 80% at 12% 0%, rgba(0,194,255,0.05), transparent 52%); }
  .card-top{ display:none; }
  .card-hd{ display:flex; align-items:center; justify-content:space-between; margin-bottom:13px; }
  .card-hd .ttl{ font-family:var(--display); font-weight:600; font-size:16px; letter-spacing:0.02em; color:#dbe9ff; }
  .card-hd .lnk{ font-size:12px; color:var(--cyan); font-weight:500; cursor:pointer; }

  .eyebrow{ font-family:var(--display); font-weight:600; font-size:11px; letter-spacing:0.3em; text-transform:uppercase; color:var(--cyan); }
  .num{ font-family:var(--display); font-weight:700; letter-spacing:0.01em; }
  .chip{ display:inline-flex; align-items:center; gap:6px; white-space:nowrap; font-size:11px; font-weight:600; padding:5px 10px; border-radius:999px;
    background:var(--blue-soft); border:1px solid var(--line); color:#bcd8ff; }
  .chip.good{ background:rgba(47,227,154,0.1); border-color:rgba(47,227,154,0.3); color:#79f3c2; }
  .pgbar{ height:8px; border-radius:99px; background:rgba(16,42,76,0.8); overflow:hidden; }
  .pgbar i{ display:block; height:100%; border-radius:99px; background:linear-gradient(90deg,var(--cyan),var(--violet)); }
  .btn-cta{ width:100%; display:flex; align-items:center; justify-content:center; gap:9px;
    font-family:var(--display); font-weight:600; font-size:15px; letter-spacing:0.02em;
    color:#02101f; padding:15px; border:none; border-radius:13px; cursor:pointer;
    background:linear-gradient(95deg,var(--cyan),var(--violet));
    box-shadow:0 8px 22px -12px rgba(0,194,255,0.6); transition:transform .12s ease, filter .12s; white-space:nowrap; }
  .btn-cta svg{ color:#02101f; }
  .btn-cta:hover{ filter:brightness(1.07); transform:translateY(-1px); }
  .btn-cta:active{ transform:translateY(1px); }
  .btn-dark{ width:100%; display:flex; align-items:center; justify-content:center; gap:10px;
    font-family:var(--display); font-weight:600; font-size:15px; letter-spacing:0.02em; color:#dff0ff;
    padding:15px; border:1px solid var(--line); border-radius:13px; cursor:pointer;
    background:var(--card-2); transition:.15s; }
  .btn-dark:hover{ background:#0c2237; border-color:var(--line-strong); }
  .iconbtn{ position:relative; width:42px; height:42px; border-radius:13px; display:grid; place-items:center;
    background:rgba(12,30,55,0.5); border:1px solid var(--line); color:#bcd8ff; cursor:pointer; }
  .gridnode{ position:absolute; border-radius:50%; background:var(--cyan); box-shadow:0 0 10px 2px rgba(0,194,255,0.8); }
  .kr-range{ -webkit-appearance:none; appearance:none; width:100%; height:6px; border-radius:99px; outline:none;
    background:linear-gradient(90deg,var(--cyan),var(--violet)); }
  .kr-range::-webkit-slider-thumb{ -webkit-appearance:none; appearance:none; width:22px; height:22px; border-radius:50%;
    background:#fff; border:3px solid var(--cyan); cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.5); }
  .kr-range::-moz-range-thumb{ width:22px; height:22px; border-radius:50%; background:#fff; border:3px solid var(--cyan); cursor:pointer; }
  @keyframes kr-fadeup{ 0%{opacity:0; transform:translateY(16px);} 100%{opacity:1; transform:translateY(0);} }
  @keyframes kr-fadein{ 0%{opacity:0;} 100%{opacity:1;} }
  @keyframes kr-glow{ 0%,100%{opacity:0.55; transform:scale(1);} 50%{opacity:1; transform:scale(1.06);} }
  @keyframes kr-rise{ 0%{opacity:0; transform:translateY(26px) scale(1.02);} 100%{opacity:1; transform:translateY(0) scale(1);} }
  @keyframes kr-shimmer{ 0%{background-position:-180% 0;} 100%{background-position:280% 0;} }
  .kr-anim-logo{ animation: kr-rise 1s cubic-bezier(.2,.8,.2,1) both; }
  .kr-anim-word{ animation: kr-fadeup .9s cubic-bezier(.2,.8,.2,1) both; animation-delay:.35s; }
  .kr-anim-body{ animation: kr-rise 1.3s cubic-bezier(.2,.8,.2,1) both; animation-delay:.5s; }
  .kr-anim-tag{ animation: kr-fadeup .9s ease both; animation-delay:1.05s; }
  .kr-glowpulse{ animation: kr-glow 3.4s ease-in-out infinite; }
  @keyframes kr-line{ 0%{width:0; opacity:0;} 100%{width:54px; opacity:1;} }
  @keyframes kr-load{ 0%{transform:translateX(-100%);} 100%{transform:translateX(320%);} }
  @keyframes kr-twinkle{ 0%,100%{opacity:.25;} 50%{opacity:.9;} }
  .kr-anim-line{ animation: kr-line 1s ease both; animation-delay:.7s; }
  .kr-loadbar{ position:relative; overflow:hidden; }
  .kr-loadbar::after{ content:""; position:absolute; top:0; left:0; height:100%; width:34%; border-radius:99px;
    background:linear-gradient(90deg,transparent,var(--cyan),transparent); animation: kr-load 1.5s ease-in-out infinite; }
  .thumb{ position:relative; border-radius:13px; overflow:hidden; flex:0 0 auto;
    background:repeating-linear-gradient(135deg,#0c2238,#0c2238 6px,#0a1b30 6px,#0a1b30 12px);
    border:1px solid var(--line); display:grid; place-items:center; color:rgba(120,165,215,0.55); }
  .thumb::after{ content:""; position:absolute; inset:0; background:radial-gradient(70% 70% at 50% 30%, rgba(0,194,255,0.12), transparent 70%); }
  `;
  const tag = document.createElement("style");
  tag.id = "kronia-styles"; tag.textContent = css;
  document.head.appendChild(tag);
})();

/* ---------- status bar ---------- */
function StatusBar() {
  return (
    <div className="statusbar">
      <span>9:41</span>
      <div className="sb-r">
        <span className="sb-bars"><i style={{height:'4px'}}></i><i style={{height:'6px'}}></i><i style={{height:'8px'}}></i><i style={{height:'11px'}}></i></span>
        <Icon name="activity" size={13} stroke={2} style={{color:'#dceaff'}} />
        <span className="sb-batt"><i></i></span>
      </div>
    </div>
  );
}

/* ---------- bottom nav ---------- */
const NAV = [
  { id: "home", icon: "home", label: "Home", target: "home" },
  { id: "treino", icon: "dumbbell", label: "Treino", target: "treino" },
  { id: "dieta", icon: "apple", label: "Dieta", target: "nutricao" },
  { id: "progresso", icon: "bars", label: "Progresso", target: "evolucao" },
  { id: "perfil", icon: "user", label: "Perfil", target: "kronos" },
];
function BottomNav({ tab, onNav }) {
  return (
    <nav className="bnav">
      {NAV.map((n) => (
        <button key={n.id} className={"bnav-item" + (tab === n.id ? " on" : "")} onClick={() => onNav(n.target)}>
          <span className="ind"></span>
          <Icon name={n.icon} size={22} stroke={tab === n.id ? 2 : 1.7} />
          <span>{n.label}</span>
        </button>
      ))}
    </nav>
  );
}

/* ---------- app bar (sub-screens) ---------- */
function AppBar({ title, subtitle, onBack, right }) {
  return (
    <div className="pad" style={{ display:"flex", alignItems:"center", gap:12, marginBottom:18 }}>
      <button className="iconbtn" style={{ width:38, height:38, borderRadius:11 }} onClick={onBack}>
        <Icon name="chevL" size={19} />
      </button>
      <div style={{ flex:1, textAlign:"center" }}>
        <div className="num" style={{ fontSize:20, color:"#fff", letterSpacing:"0.02em" }}>{title}</div>
        {subtitle && <div style={{ fontSize:11.5, color:"var(--cyan)", marginTop:2 }}>{subtitle}</div>}
      </div>
      <div style={{ width:38, height:38, display:"grid", placeItems:"center" }}>{right || <Icon name="more" size={20} style={{color:"var(--muted)"}} />}</div>
    </div>
  );
}

/* ---------- progress ring ---------- */
function Ring({ size = 150, stroke = 12, pct = 85, value, unit, label, sub, valueSize }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, off = c * (1 - pct / 100);
  const gid = "rg" + Math.round(pct*10) + "-" + size;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)", filter: "drop-shadow(0 0 9px rgba(109,74,254,0.45))" }}>
        <defs><linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--cyan)" /><stop offset="55%" stopColor="var(--blue)" /><stop offset="100%" stopColor="var(--violet)" />
        </linearGradient></defs>
        <circle cx={size/2} cy={size/2} r={r} stroke="rgba(18,48,90,0.7)" strokeWidth={stroke} fill="none" />
        <circle cx={size/2} cy={size/2} r={r} stroke={`url(#${gid})`} strokeWidth={stroke} fill="none"
          strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1s cubic-bezier(.2,.8,.2,1)" }} />
      </svg>
      <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
        <span className="num" style={{ fontSize: valueSize || size*0.27, lineHeight:1, color:"#fff" }}>{value}{unit && <span style={{fontSize:(valueSize||size*0.27)*0.42, color:"var(--muted)", marginLeft:1}}>{unit}</span>}</span>
        {label && <span className="num" style={{ fontSize:11, marginTop:3, color:"var(--good)", letterSpacing:"0.14em" }}>{label}</span>}
        {sub && <span style={{ fontSize:11, color:"var(--muted)", marginTop:2 }}>{sub}</span>}
      </div>
    </div>
  );
}

/* ---------- mini ring (macro pills) ---------- */
function MiniRing({ size = 64, stroke = 6, pct = 80, value, label }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, off = c * (1 - pct / 100);
  const gid = "mr" + Math.round(pct*10) + "-" + size + "-" + value;
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:8 }}>
      <div style={{ position:"relative", width:size, height:size }}>
        <svg width={size} height={size} style={{ transform:"rotate(-90deg)" }}>
          <defs><linearGradient id={gid} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="var(--cyan)" /><stop offset="55%" stopColor="var(--blue)" /><stop offset="100%" stopColor="var(--violet)" /></linearGradient></defs>
          <circle cx={size/2} cy={size/2} r={r} stroke="rgba(18,48,90,0.7)" strokeWidth={stroke} fill="none" />
          <circle cx={size/2} cy={size/2} r={r} stroke={`url(#${gid})`} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round" />
        </svg>
        <div style={{ position:"absolute", inset:0, display:"grid", placeItems:"center" }}>
          <span className="num" style={{ fontSize:15, color:"#fff" }}>{value}</span>
        </div>
      </div>
      <span style={{ fontSize:11, color:"var(--muted)", fontWeight:500 }}>{label}</span>
    </div>
  );
}

/* ---------- sparkline ---------- */
function Sparkline({ pts = [20,28,24,34,30,42,38], w = 96, h = 34, color = "var(--cyan)" }) {
  const max = Math.max(...pts), min = Math.min(...pts), rng = max - min || 1;
  const path = pts.map((p,i)=>`${(i/(pts.length-1))*w},${h-((p-min)/rng)*h}`).join(" ");
  return (
    <svg width={w} height={h} style={{ overflow:"visible" }}>
      <polyline points={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ filter:"drop-shadow(0 0 4px rgba(0,194,255,0.6))" }} />
      <circle cx={w} cy={h-((pts[pts.length-1]-min)/rng)*h} r="3" fill={color} />
    </svg>
  );
}

/* ---------- glowing 3D body figure (real render via window.KRONIA_BODY) ---------- */
/* muscle glow regions as % of the front-view image (cx, cy, size) */
const MUSCLE_SPOT = {
  peito:   { cx:50, cy:30, rx:30, ry:14 },
  ombros:  { cx:50, cy:24, rx:42, ry:11 },
  costas:  { cx:50, cy:33, rx:34, ry:18 },
  pernas:  { cx:50, cy:68, rx:30, ry:24 },
};
function BodyFigure({ w = 150, h = 300, highlight = null, dim = false, label = false, back = false }) {
  const src = (typeof window !== "undefined" && (back ? window.KRONIA_BODY_BACK : window.KRONIA_BODY)) || "";
  const spot = highlight && MUSCLE_SPOT[highlight];
  const hotColor = highlight === "_warn" ? "rgba(255,181,71,0.9)" : "rgba(0,210,255,0.95)";
  return (
    <div style={{ position:"relative", width:w, height:h }}>
      {/* ambient aura */}
      <div style={{ position:"absolute", inset:"-6% 2%", background:"radial-gradient(52% 50% at 50% 40%, rgba(0,150,255,0.22), rgba(26,127,232,0.08) 50%, transparent 74%)", filter:"blur(6px)" }}></div>
      {/* the render */}
      {src
        ? <img src={src} alt="" draggable="false" style={{ position:"relative", zIndex:1, width:"100%", height:"100%", objectFit:"contain",
            filter: highlight ? "brightness(0.5) saturate(0.7)" : "none", transition:"filter .3s" }} />
        : <div style={{ position:"absolute", inset:0, display:"grid", placeItems:"center", color:"rgba(120,165,215,0.5)", fontFamily:"monospace", fontSize:9 }}>CORPO 3D</div>}
      {/* muscle highlight glow */}
      {spot && (
        <div style={{ position:"absolute", zIndex:2, left:`${spot.cx}%`, top:`${spot.cy}%`, width:`${spot.rx*2}%`, height:`${spot.ry*2}%`,
          transform:"translate(-50%,-50%)", borderRadius:"50%",
          background:`radial-gradient(circle, ${hotColor}, transparent 70%)`, mixBlendMode:"screen", filter:"blur(2px)" }}></div>
      )}
      {label && <div style={{ position:"absolute", bottom:-2, left:0, right:0, textAlign:"center", fontFamily:"monospace", fontSize:8, letterSpacing:"0.14em", color:"rgba(120,165,215,0.5)" }}>CORPO 3D</div>}
    </div>
  );
}

/* ---------- tabs ---------- */
function Tabs({ tabs, active, onChange }) {
  return (
    <div style={{ display:"flex", gap:6, background:"rgba(8,22,40,0.7)", border:"1px solid var(--line)", borderRadius:13, padding:4 }}>
      {tabs.map(t=>(
        <button key={t} onClick={()=>onChange(t)} style={{
          flex:1, padding:"9px 4px", borderRadius:9, border:"none", cursor:"pointer",
          fontFamily:"var(--display)", fontWeight:600, fontSize:13, letterSpacing:"0.02em",
          color: active===t?"#02101f":"var(--muted)",
          background: active===t?"linear-gradient(100deg,var(--cyan),var(--blue))":"transparent",
          boxShadow: active===t?"0 4px 14px -4px rgba(0,150,255,0.6)":"none", transition:".15s" }}>{t}</button>
      ))}
    </div>
  );
}

/* ---------- phone shell ---------- */
function PhoneShell({ tab, onNav, children, showNav = true, bare = false, flat = false }) {
  const screen = (
    <div className="phone-screen" style={ flat ? { borderRadius: 0, height: 812 } : {} }>
      <div className="island"></div>
      {!bare && <StatusBar />}
      <div className="screen-scroll" style={ showNav ? {} : { paddingBottom: 28 } }>{children}</div>
      {showNav && <BottomNav tab={tab} onNav={onNav} />}
    </div>
  );
  if (flat) return screen;
  return <div className="phone">{screen}</div>;
}

Object.assign(window, { StatusBar, BottomNav, AppBar, Ring, MiniRing, Sparkline, BodyFigure, Tabs, PhoneShell, NAV });
