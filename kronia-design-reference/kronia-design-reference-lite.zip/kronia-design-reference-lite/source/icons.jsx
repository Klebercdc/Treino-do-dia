/* ============================================================
   KRONIA — thin line icon set (Lucide-style, 24x24, stroke)
   ============================================================ */
const ICON_PATHS = {
  home: <><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9.5"/><path d="M9.5 21v-6h5v6"/></>,
  dumbbell: <><path d="M6.5 6.5v11M3.5 9v6M17.5 6.5v11M20.5 9v6M6.5 12h11"/></>,
  apple: <><path d="M12 7c-1.5-2-4-2.2-5.5-1C4.7 7.4 4.5 10 5.5 13c.8 2.4 2.2 5 4 5 .9 0 1.5-.5 2.5-.5s1.6.5 2.5.5c1.8 0 3.2-2.6 4-5 1-3 .8-5.6-1-7-1.5-1.2-4-1-5.5 1Z"/><path d="M12 7c0-1.5.6-3 2-3.7"/></>,
  trending: <><path d="M3 17l6-6 4 4 8-8"/><path d="M16 7h5v5"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></>,
  activity: <><path d="M3 12h4l3 8 4-16 3 8h4"/></>,
  zap: <><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/></>,
  flame: <><path d="M12 3c2 3.5 5 5 5 9a5 5 0 0 1-10 0c0-1.6.7-2.8 1.5-3.8.4 1 1.2 1.6 2 1.8-.5-3 .8-5.4 1.5-7Z"/></>,
  droplet: <><path d="M12 3c3 4 6 6.7 6 10.5A6 6 0 0 1 6 13.5C6 9.7 9 7 12 3Z"/></>,
  target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.3"/></>,
  chevR: <><path d="m9 5 7 7-7 7"/></>,
  chevL: <><path d="m15 5-7 7 7 7"/></>,
  chevD: <><path d="m5 9 7 7 7-7"/></>,
  plus: <><path d="M12 5v14M5 12h14"/></>,
  check: <><path d="m4 12.5 5 5 11-11"/></>,
  lock: <><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></>,
  moon: <><path d="M20 14.5A8 8 0 0 1 9.5 4 7 7 0 1 0 20 14.5Z"/></>,
  brain: <><path d="M9.5 4.5A2.5 2.5 0 0 0 7 7a2.5 2.5 0 0 0-1 4.8M9.5 4.5A2 2 0 0 1 12 6.3V19M9.5 4.5C8 4.5 7 5.3 7 7M12 6.3A2 2 0 0 1 14.5 4.5 2.5 2.5 0 0 1 17 7a2.5 2.5 0 0 1 1 4.8M7 11.8C5.5 12.3 5 13.4 5 14.6A2.4 2.4 0 0 0 8 17M17 11.8c1.5.5 2 1.6 2 2.8A2.4 2.4 0 0 1 16 17M8 17a2.2 2.2 0 0 0 4 .5M16 17a2.2 2.2 0 0 1-4 .5"/></>,
  message: <><path d="M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H9l-4 4V6a1 1 0 0 1 1-1Z"/></>,
  upload: <><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></>,
  file: <><path d="M7 3h7l5 5v12a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v5h5"/></>,
  heart: <><path d="M12 20s-7-4.3-9.2-8.5C1.2 8.3 2.8 5 6 5c2 0 3.2 1.3 4 2.5C10.8 6.3 12 5 14 5c3.2 0 4.8 3.3 3.2 6.5C19 15.7 12 20 12 20Z"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></>,
  bars: <><path d="M5 21V10M12 21V4M19 21v-7"/></>,
  award: <><circle cx="12" cy="9" r="5"/><path d="m9 13-1.5 8L12 18l4.5 3L15 13"/></>,
  calendar: <><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M4 9h16M9 3v4M15 3v4"/></>,
  bell: <><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z"/><path d="M10 20a2 2 0 0 0 4 0"/></>,
  sparkle: <><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="M19 3.5l.6 1.9 1.9.6-1.9.6L19 8.5l-.6-1.9L16.5 6l1.9-.6Z"/></>,
  scan: <><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/></>,
  refresh: <><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 4v4h-4"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16M3 20v-4h4"/></>,
  play: <><path d="M7 4.5 19 12 7 19.5v-15Z"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M5 5l2 2M17 17l2 2M2 12h3M19 12h3M5 19l2-2M17 7l2-2"/></>,
  shield: <><path d="M12 3 5 6v5c0 4.5 3 7.6 7 9 4-1.4 7-4.5 7-9V6l-7-3Z"/></>,
  bolt: <><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/></>,
  arrowUp: <><path d="M12 19V5M6 11l6-6 6 6"/></>,
  arrowR: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
  pizza: <><path d="M12 3c5 0 9 3 9 6L12 21 3 9c0-3 4-6 9-6Z"/><circle cx="10" cy="9" r="1"/><circle cx="13.5" cy="12" r="1"/></>,
  egg: <><path d="M12 3c4 0 7 6 7 10a7 7 0 0 1-14 0c0-4 3-10 7-10Z"/></>,
  ruler: <><rect x="3" y="8" width="18" height="8" rx="1"/><path d="M7 8v3M11 8v4M15 8v3M19 8v4"/></>,
  beaker: <><path d="M9 3v6L5 18a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-4-9V3"/><path d="M8 3h8M7.5 13h9"/></>,
  more: <><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></>,
  wave: <><path d="M2 12h3l2-6 3 13 3-16 2.5 9H22"/></>,
  chart: <><path d="M4 19V5M4 19h16M8 16l3.5-4 3 2.5L20 8"/></>,
};

function Icon({ name, size = 22, stroke = 1.6, className = "", style = {}, fill = "none" }) {
  const d = ICON_PATHS[name];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
      stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      className={className} style={style} aria-hidden="true">
      {d || null}
    </svg>
  );
}

Object.assign(window, { Icon, ICON_PATHS });
