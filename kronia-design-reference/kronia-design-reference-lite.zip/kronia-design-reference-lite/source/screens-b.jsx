/* ============================================================
   KRONIA — Screens 6–10 (Recuperação · Anamnese · Kronos · Exames · Splash)
   ============================================================ */

/* ---------------- 6. RECUPERAÇÃO ---------------- */
function RecuperacaoScreen({ onNav }) {
  const [fatigue, setFatigue] = React.useState(3);
  const [sleep, setSleep] = React.useState(7.5);
  const readiness = Math.round(100 - fatigue*7 - Math.max(0, (8-sleep))*5);
  const muscles = [
    { n:"Peito", st:"Pronto", key:"peito", warn:false },
    { n:"Costas", st:"Pronto", key:"costas", warn:false },
    { n:"Pernas", st:"Atenção", key:"pernas", warn:true },
    { n:"Ombros", st:"Pronto", key:"ombros", warn:false },
  ];
  const fatigueLabel = fatigue<=3 ? "Baixa" : fatigue<=6 ? "Moderada" : "Alta";
  return (
    <>
      <AppBar title="Recuperação" onBack={()=>onNav("home")} />

      {/* readiness derived from self-report */}
      <div className="pad">
        <div className="card glow" style={{ display:"flex", alignItems:"center", gap:14, padding:"18px 16px" }}>
          <div style={{ flex:"0 0 auto", textAlign:"center" }}>
            <Ring size={128} stroke={12} pct={readiness} value={String(readiness)} valueSize={34} />
            <div style={{ fontSize:10.5, color:"var(--muted)", marginTop:7, maxWidth:118, lineHeight:1.4 }}>Prontidão calculada</div>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, color:"#dbe9ff", fontWeight:600 }}>Como você se sente?</div>
            <div style={{ fontSize:11.5, color:"var(--muted)", marginTop:3, lineHeight:1.45 }}>Esse valor é auto-declarado — alimenta a prontidão na Home.</div>
            <Sparkline pts={[24,30,26,34,32,40,readiness*0.5]} w={120} h={30} />
          </div>
        </div>
      </div>

      {/* fatigue slider */}
      <div className="pad" style={{ marginTop:14 }}>
        <div className="card">
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginBottom:10 }}>
            <span style={{ fontSize:13.5, color:"#dbe9ff", fontWeight:600 }}>Nível de fadiga</span>
            <span><span className="num" style={{ fontSize:22, color:"var(--cyan)" }}>{fatigue}</span><span style={{ fontSize:12, color:"var(--muted-d)" }}>/10 · {fatigueLabel}</span></span>
          </div>
          <input type="range" min="0" max="10" step="1" value={fatigue} onChange={e=>setFatigue(+e.target.value)} className="kr-range" />
          <div style={{ display:"flex", justifyContent:"space-between", marginTop:6, fontSize:10, color:"var(--muted-d)" }}><span>Descansado</span><span>Exausto</span></div>
        </div>
      </div>

      {/* sleep */}
      <div className="pad" style={{ marginTop:12 }}>
        <div className="card" style={{ display:"flex", alignItems:"center", gap:13 }}>
          <span style={{ flex:"0 0 auto", width:42, height:42, borderRadius:12, display:"grid", placeItems:"center", background:"var(--blue-soft)", border:"1px solid var(--line)", color:"var(--cyan)" }}><Icon name="moon" size={20} /></span>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, color:"var(--muted)" }}>Sono na última noite</div>
            <div className="num" style={{ fontSize:20, color:"#fff" }}>{sleep.toFixed(1).replace(".",",")}h</div>
          </div>
          <div style={{ display:"flex", gap:7 }}>
            <button onClick={()=>setSleep(s=>Math.max(0,+(s-0.5).toFixed(1)))} style={stepBtn}><Icon name="chevD" size={16} /></button>
            <button onClick={()=>setSleep(s=>Math.min(12,+(s+0.5).toFixed(1)))} style={{...stepBtn, transform:"rotate(180deg)"}}><Icon name="chevD" size={16} /></button>
          </div>
        </div>
      </div>

      <div className="pad" style={{ marginTop:16 }}>
        <div className="card-hd"><div className="ttl">Grupos musculares</div><span className="lnk">Frente / Costas</span></div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:9 }}>
          {muscles.map((m,i)=>(
            <div key={i} className="card" style={{ padding:"8px 4px 11px", textAlign:"center" }}>
              <div style={{ height:78, display:"flex", justifyContent:"center", alignItems:"center", position:"relative" }}>
                <div style={{ position:"absolute", inset:"8% 10%", background:"radial-gradient(60% 60% at 50% 45%, "+(m.warn?"rgba(255,181,71,0.18)":"rgba(0,194,255,0.18)")+", transparent 72%)", filter:"blur(3px)" }}></div>
                <img src={(window.KRONIA_MUSCLE||{})[m.key]} alt="" draggable="false" style={{ position:"relative", maxWidth:"100%", maxHeight:"78px", objectFit:"contain", filter: m.warn?"saturate(1.1) hue-rotate(-12deg) brightness(1.05)":"none" }} />
              </div>
              <div style={{ fontSize:11.5, color:"#dbe9ff", fontWeight:600, marginTop:6 }}>{m.n}</div>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:4, marginTop:3 }}>
                <span style={{ width:6, height:6, borderRadius:"50%", background: m.warn?"var(--warn)":"var(--good)" }}></span>
                <span style={{ fontSize:10.5, color: m.warn?"var(--warn)":"var(--good)" }}>{m.st}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="pad" style={{ marginTop:14 }}>
        <div className="card" style={{ display:"flex", gap:13, alignItems:"flex-start" }}>
          <span style={{ flex:"0 0 auto", width:38, height:38, borderRadius:11, display:"grid", placeItems:"center", background:"var(--blue-soft)", border:"1px solid var(--line)", color:"var(--cyan)" }}><Icon name="droplet" size={19} /></span>
          <div><div style={{ fontSize:11, color:"var(--cyan)", fontWeight:700, letterSpacing:"0.12em", textTransform:"uppercase" }}>Dica do sistema</div><div style={{ fontSize:13, color:"#cfe3ff", marginTop:5, lineHeight:1.5 }}>Pernas em atenção — priorize alongamento e hidratação hoje.</div></div>
        </div>
      </div>
    </>
  );
}
const stepBtn = { width:34, height:34, borderRadius:10, border:"1px solid var(--line)", background:"var(--card-2)", color:"#bcd8ff", cursor:"pointer", display:"grid", placeItems:"center" };

/* ---------------- 7. GERAÇÃO DA DIETA — ANAMNESE ---------------- */
function AnamneseScreen({ onNav }) {
  const items = ["Entendendo sua rotina","Analisando seus objetivos","Avaliando seus hábitos","Considerando sua evolução"];
  return (
    <>
      <AppBar title="Geração da Dieta - Anamnese" onBack={()=>onNav("nutricao")} right={<span></span>} />
      <div className="pad" style={{ display:"flex", justifyContent:"center", margin:"6px 0 22px", position:"relative" }}>
        <div style={{ position:"relative", width:230, height:175, display:"grid", placeItems:"center" }}>
          <div className="kr-glowpulse" style={{ position:"absolute", inset:"-6%", background:"radial-gradient(50% 50% at 50% 50%, rgba(0,150,255,0.26), transparent 70%)", filter:"blur(10px)" }}></div>
          <img src={(typeof window!=='undefined'&&window.KRONIA_PLANET)||''} alt="" draggable="false" style={{ position:"relative", width:230, height:"auto", objectFit:"contain" }} />
        </div>
      </div>

      <div className="pad" style={{ display:"flex", flexDirection:"column", gap:11 }}>
        {items.map((t,i)=>(
          <div key={i} className="card" style={{ display:"flex", gap:13, alignItems:"center", padding:"13px 14px" }}>
            <span style={{ flex:"0 0 auto", width:30, height:30, borderRadius:"50%", display:"grid", placeItems:"center", background:"rgba(47,227,154,0.14)", border:"1px solid rgba(47,227,154,0.4)", color:"var(--good)" }}><Icon name="check" size={16} stroke={2.6} /></span>
            <div style={{ fontSize:14, fontWeight:600, color:"#eaf3ff" }}>{t}</div>
          </div>
        ))}
      </div>

      <div className="pad" style={{ marginTop:18 }}>
        <div className="card glow" style={{ padding:"18px 16px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:11, marginBottom:14 }}>
            <span style={{ width:40, height:40, borderRadius:12, display:"grid", placeItems:"center", background:"var(--blue-soft)", border:"1px solid var(--line)", color:"var(--cyan)" }}><Icon name="brain" size={22} /></span>
            <div className="num" style={{ fontSize:16.5, color:"#fff" }}>IA gerando seu plano alimentar…</div>
          </div>
          <div className="pgbar" style={{ height:9 }}><i style={{ width:"78%" }}></i></div>
          <div style={{ textAlign:"right", marginTop:8 }}><span className="num" style={{ fontSize:14, color:"var(--cyan)" }}>78%</span></div>
        </div>
      </div>
    </>
  );
}

/* ---------------- 8. KRONOS ---------------- */
function KronosScreen({ onNav }) {
  const seed = [
    { who:"k", t:"Boa noite, Kleber. Analisei seus últimos 7 dias de treino, dieta e seu painel hormonal.", time:"10:28" },
    { who:"k", insight:true, icon:"chart", title:"Insight clínico", t:"Seu volume de treino subiu 12% e a fadiga registrada caiu. Janela boa para progredir carga no supino (+2,5kg).", time:"10:30" },
    { who:"u", t:"Posso aumentar a proteína?", time:"10:31" },
    { who:"k", t:"Sim. Com seu peso atual sugiro 1,9 g/kg — ajustei sua meta para 175g. Quer que eu atualize o plano?", time:"10:31" },
  ];
  const chips = ["Como está minha recuperação?", "Ajustar minha dieta", "Explicar meu exame"];
  const [msgs, setMsgs] = React.useState(seed);
  const [draft, setDraft] = React.useState("");
  const scRef = React.useRef(null);
  const send = (text) => {
    const t = (text || draft).trim(); if (!t) return;
    setDraft("");
    setMsgs(m => [...m, { who:"u", t, time:"agora" }]);
    setTimeout(()=> setMsgs(m => [...m, { who:"k", t:"Entendido. Vou cruzar isso com seus dados e te respondo com um plano em instantes.", time:"agora" }]), 650);
  };
  React.useEffect(()=>{ if (scRef.current) scRef.current.scrollTop = scRef.current.scrollHeight; }, [msgs]);

  return (
    <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", paddingTop:54 }}>
      {/* header */}
      <div className="pad" style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 16px 12px", borderBottom:"1px solid var(--line)" }}>
        <button className="iconbtn" style={{ width:36, height:36, borderRadius:11 }} onClick={()=>onNav("home")}><Icon name="chevL" size={18} /></button>
        <KLogo size={26} />
        <div style={{ flex:1 }}>
          <div className="num" style={{ fontSize:18, color:"#fff", lineHeight:1 }}>KRONOS</div>
          <div style={{ fontSize:11, color:"var(--good)", marginTop:3, display:"flex", alignItems:"center", gap:5 }}><span style={{ width:6, height:6, borderRadius:"50%", background:"var(--good)" }}></span> online · coach que nunca dorme</div>
        </div>
      </div>

      {/* messages */}
      <div ref={scRef} style={{ flex:1, overflowY:"auto", padding:"16px 16px 6px", display:"flex", flexDirection:"column", gap:11 }}>
        {msgs.map((m,i)=> m.insight ? (
          <div key={i} className="card" style={{ alignSelf:"flex-start", maxWidth:"88%", padding:"13px 14px", borderColor:"rgba(0,194,255,0.3)" }}>
            <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:9 }}>
              <span style={{ width:30, height:30, borderRadius:9, display:"grid", placeItems:"center", background:"linear-gradient(150deg,rgba(0,194,255,0.2),rgba(109,74,254,0.18))", border:"1px solid rgba(0,194,255,0.35)", color:"var(--cyan)" }}><Icon name={m.icon} size={16} /></span>
              <span style={{ fontFamily:"var(--display)", fontWeight:600, fontSize:12, letterSpacing:"0.08em", textTransform:"uppercase", color:"var(--cyan)" }}>{m.title}</span>
            </div>
            <div style={{ fontSize:13.5, color:"#dbe8f8", lineHeight:1.5 }}>{m.t}</div>
            <div style={{ display:"flex", gap:8, marginTop:11 }}>
              <button onClick={()=>send("Pode progredir a carga")} style={{ flex:1, padding:"8px", borderRadius:9, border:"none", cursor:"pointer", background:"linear-gradient(95deg,var(--cyan),var(--violet))", color:"#02101f", fontFamily:"var(--display)", fontWeight:600, fontSize:12 }}>Aplicar</button>
              <button style={{ flex:1, padding:"8px", borderRadius:9, border:"1px solid var(--line)", cursor:"pointer", background:"var(--card-2)", color:"#bcd8ff", fontFamily:"var(--display)", fontWeight:600, fontSize:12 }}>Depois</button>
            </div>
            <div style={{ fontSize:10, color:"var(--muted-d)", marginTop:8 }}>{m.time}</div>
          </div>
        ) : (
          <div key={i} style={{ alignSelf: m.who==="u"?"flex-end":"flex-start", maxWidth:"82%" }}>
            <div style={{ padding:"10px 13px", borderRadius: m.who==="u"?"14px 14px 4px 14px":"14px 14px 14px 4px",
              background: m.who==="u"?"linear-gradient(95deg,var(--cyan),var(--violet))":"var(--card)",
              border: m.who==="u"?"none":"1px solid var(--line)",
              color: m.who==="u"?"#02101f":"#dbe8f8", fontSize:13.5, lineHeight:1.45, fontWeight: m.who==="u"?500:400 }}>{m.t}</div>
            <div style={{ fontSize:10, color:"var(--muted-d)", marginTop:4, textAlign: m.who==="u"?"right":"left" }}>{m.time}</div>
          </div>
        ))}
      </div>

      {/* quick chips */}
      <div style={{ display:"flex", gap:8, overflowX:"auto", padding:"6px 16px 10px", scrollbarWidth:"none" }}>
        {chips.map((c,i)=>(
          <button key={i} onClick={()=>send(c)} style={{ flex:"0 0 auto", padding:"8px 13px", borderRadius:999, border:"1px solid var(--line)", background:"var(--card)", color:"#bcd8ff", fontSize:12, fontWeight:500, cursor:"pointer", whiteSpace:"nowrap" }}>{c}</button>
        ))}
      </div>

      {/* input */}
      <div style={{ padding:"0 16px calc(82px + 12px)", paddingBottom:"96px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, background:"var(--card)", border:"1px solid var(--line-strong)", borderRadius:16, padding:"6px 6px 6px 16px" }}>
          <input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") send(); }}
            placeholder="Pergunte ao Kronos…" style={{ flex:1, background:"none", border:"none", outline:"none", color:"#eaf3ff", fontFamily:"var(--body)", fontSize:13 }} />
          <button onClick={()=>send()} style={{ width:40, height:40, borderRadius:12, border:"none", cursor:"pointer", display:"grid", placeItems:"center", background:"linear-gradient(95deg,var(--cyan),var(--violet))", color:"#02101f" }}><Icon name="arrowR" size={19} stroke={2.2} /></button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 9. EXAMES ---------------- */
function ExamesScreen({ onNav }) {
  const [hasExams, setHasExams] = React.useState(true);
  const exams = [
    { n:"Painel Hormonal", date:"20/05/2025", st:"Analisado" },
    { n:"Hemograma Completo", date:"20/05/2025", st:"Analisado" },
    { n:"Ferritina", date:"10/04/2025", st:"Atenção" },
  ];
  const biomarkers = [
    { n:"Testosterona", v:"680", u:"ng/dL", st:"normal" },
    { n:"TSH", v:"2,1", u:"mUI/L", st:"normal" },
    { n:"Hemoglobina", v:"15,2", u:"g/dL", st:"normal" },
    { n:"Ferritina", v:"38", u:"ng/mL", st:"atencao" },
    { n:"Vitamina D", v:"28", u:"ng/mL", st:"atencao" },
    { n:"Glicose", v:"92", u:"mg/dL", st:"normal" },
  ];
  const stColor = (s)=> s==="alto"?"var(--bad)": s==="atencao"?"var(--warn)":"var(--good)";
  const stLabel = (s)=> s==="alto"?"Alto": s==="atencao"?"Atenção":"Normal";
  return (
    <>
      <AppBar title="Exames" subtitle="Exames aumentam a precisão do KRONOS" onBack={()=>onNav("nutricao")} right={<button onClick={()=>setHasExams(h=>!h)} style={{all:"unset",cursor:"pointer"}}><Icon name="refresh" size={18} style={{ color:"var(--muted-d)" }} /></button>} />

      {/* upload */}
      <div className="pad">
        <div className="card" style={{ border:"1.5px dashed var(--line-strong)", textAlign:"center", padding:"24px 16px" }}>
          <span style={{ width:54, height:54, borderRadius:16, display:"grid", placeItems:"center", margin:"0 auto 12px", background:"linear-gradient(150deg,rgba(0,194,255,0.16),rgba(109,74,254,0.14))", border:"1px solid rgba(0,194,255,0.3)", color:"var(--cyan)" }}><Icon name="upload" size={26} /></span>
          <div className="num" style={{ fontSize:18, color:"#fff" }}>Enviar exame</div>
          <div style={{ fontSize:12.5, color:"var(--muted)", marginTop:5 }}>O KRONOS lê e extrai seus biomarcadores</div>
          <div style={{ display:"flex", gap:7, justifyContent:"center", marginTop:13 }}>
            {["PDF","JPEG","PNG"].map(t=>(<span key={t} className="chip" style={{ fontFamily:"var(--display)", letterSpacing:"0.06em" }}>{t}</span>))}
          </div>
        </div>
      </div>

      {!hasExams ? (
        /* ---- empty state ---- */
        <div className="pad" style={{ marginTop:16 }}>
          <div className="card" style={{ textAlign:"center", padding:"30px 22px" }}>
            <span style={{ width:52, height:52, borderRadius:15, display:"grid", placeItems:"center", margin:"0 auto 16px", background:"var(--card-2)", border:"1px solid var(--line)", color:"var(--muted-d)" }}><Icon name="beaker" size={26} /></span>
            <div className="num" style={{ fontSize:18, color:"#fff" }}>Nenhum exame ainda</div>
            <div style={{ fontSize:13, color:"var(--muted)", marginTop:8, lineHeight:1.5, maxWidth:250, marginLeft:"auto", marginRight:"auto" }}>
              Envie seu primeiro exame para o KRONOS cruzar seus biomarcadores com treino e dieta.
            </div>
            <div style={{ marginTop:20 }}><button className="btn-cta" onClick={()=>setHasExams(true)}><Icon name="upload" size={17} /> Enviar primeiro exame</button></div>
          </div>
        </div>
      ) : (
        <>
          {/* biomarkers grid */}
          <div className="pad" style={{ marginTop:18 }}>
            <div className="card-hd"><div className="ttl">Biomarcadores</div><span className="lnk">Painel Hormonal</span></div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {biomarkers.map((b,i)=>(
                <div key={i} className="card" style={{ padding:"13px 13px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                    <span style={{ fontSize:12, color:"var(--muted)", fontWeight:500 }}>{b.n}</span>
                    <span style={{ width:8, height:8, borderRadius:"50%", background:stColor(b.st), flex:"0 0 auto", marginTop:3 }}></span>
                  </div>
                  <div style={{ marginTop:8, display:"flex", alignItems:"baseline", gap:4 }}>
                    <span className="num" style={{ fontSize:22, color:"#fff" }}>{b.v}</span>
                    <span style={{ fontSize:11, color:"var(--muted-d)" }}>{b.u}</span>
                  </div>
                  <div style={{ fontSize:10.5, fontWeight:600, color:stColor(b.st), marginTop:5 }}>{stLabel(b.st)}</div>
                </div>
              ))}
            </div>
          </div>

          {/* history */}
          <div className="pad" style={{ marginTop:18 }}>
            <div className="card-hd"><div className="ttl">Histórico</div><span className="lnk">Ver todos</span></div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {exams.map((e,i)=>(
                <div key={i} className="card" style={{ display:"flex", gap:13, alignItems:"center", padding:"13px 14px" }}>
                  <span style={{ flex:"0 0 auto", width:42, height:42, borderRadius:12, display:"grid", placeItems:"center", background:"var(--blue-soft)", border:"1px solid var(--line)", color:"var(--cyan)" }}><Icon name="file" size={20} /></span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:14, fontWeight:700, color:"#fff" }}>{e.n}</div>
                    <div style={{ fontSize:11.5, color:"var(--muted)", marginTop:3 }}>{e.date}</div>
                  </div>
                  <span style={{ fontSize:10.5, fontWeight:700, letterSpacing:"0.04em", textTransform:"uppercase", color: e.st==="Atenção"?"var(--warn)":"var(--good)" }}>{e.st}</span>
                  <Icon name="chevR" size={17} style={{ color:"var(--muted-d)" }} />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </>
  );
}

/* ---------------- 10. SPLASH / BRAND ---------------- */
function SplashScreen({ onNav }) {
  const logo = (typeof window!=='undefined'&&window.KRONIA_LOGO)||'';
  const body = (typeof window!=='undefined'&&window.KRONIA_SPLASH)||'';
  const [replay, setReplay] = React.useState(0);
  return (
    <div key={replay} style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"flex-start", paddingTop:84,
      background:"radial-gradient(70% 48% at 50% 40%, rgba(0,194,255,0.16), rgba(109,74,254,0.06) 44%, transparent 74%)" }}>
      <div style={{ position:"absolute", inset:0, backgroundImage:"linear-gradient(rgba(40,90,150,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(40,90,150,0.05) 1px,transparent 1px)", backgroundSize:"36px 36px", maskImage:"radial-gradient(62% 58% at 50% 40%,#000,transparent 80%)" }}></div>

      {/* K mark */}
      <div className="kr-anim-logo" style={{ position:"relative", marginBottom:14 }}>
        <div className="kr-glowpulse" style={{ position:"absolute", inset:"-28px", background:"radial-gradient(circle,rgba(0,194,255,0.42),transparent 66%)", filter:"blur(7px)" }}></div>
        {logo
          ? <img src={logo} alt="K" draggable="false" style={{ position:"relative", height:80, width:"auto", filter:"drop-shadow(0 0 22px rgba(0,194,255,0.7))" }} />
          : <span style={{ position:"relative", fontFamily:"var(--display)", fontWeight:700, fontSize:104, lineHeight:1, color:"#fff" }}>K</span>}
      </div>
      <div className="kr-anim-word" style={{ fontFamily:"var(--display)", fontWeight:700, fontSize:34, letterSpacing:"0.5em", color:"#fff", paddingLeft:"0.5em", textShadow:"0 0 28px rgba(0,194,255,0.55)" }}>KRONIA</div>
      <div className="kr-anim-line" style={{ height:2, borderRadius:2, margin:"13px 0 11px", background:"linear-gradient(90deg,transparent,var(--cyan),transparent)" }}></div>
      <div className="kr-anim-word" style={{ fontFamily:"var(--display)", fontWeight:500, fontSize:13, letterSpacing:"0.16em", color:"var(--cyan)", animationDelay:"0.5s" }}>O coach que nunca dorme</div>

      {body && <div className="kr-anim-body" style={{ marginTop:16, position:"relative", flex:"0 1 auto", minHeight:0 }}>
        <img src={body} alt="" draggable="false" style={{ position:"relative", width:300, height:"auto", display:"block", maxHeight:"260px", objectFit:"contain" }} />
      </div>}

      <div className="kr-anim-tag" style={{ position:"absolute", bottom:30, left:24, right:24, display:"flex", flexDirection:"column", gap:11 }}>
        <button className="btn-cta" onClick={()=>onNav("home")}>Criar conta</button>
        <button className="btn-dark" onClick={()=>onNav("home")}>Já tenho conta</button>
        <div style={{ textAlign:"center", fontSize:10.5, color:"var(--muted-d)", letterSpacing:"0.04em", marginTop:2 }}>Free · Pro R$29,90 · Ultra R$59,90</div>
      </div>
    </div>
  );
}

Object.assign(window, { RecuperacaoScreen, AnamneseScreen, KronosScreen, ExamesScreen, SplashScreen });
