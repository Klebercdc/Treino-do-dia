/* ============================================================
   KRONIA — gallery app shell
   Renders all 10 screens as live, independently-navigable phones.
   ============================================================ */

/* screen registry: id -> { tab (for nav highlight), render, showNav } */
const SCREENS = {
  splash:      { tab:null,        showNav:false, comp:(p)=> <SplashScreen {...p} /> },
  home:        { tab:"home",      showNav:true,  comp:(p)=> <HomeScreen {...p} /> },
  treino:      { tab:"treino",    showNav:true,  comp:(p)=> <TreinoScreen {...p} /> },
  nutricao:    { tab:"dieta",     showNav:true,  comp:(p)=> <NutricaoScreen {...p} /> },
  refeicoes:   { tab:"dieta",     showNav:true,  comp:(p)=> <RefeicoesScreen {...p} /> },
  evolucao:    { tab:"progresso", showNav:true,  comp:(p)=> <EvolucaoScreen {...p} /> },
  recuperacao: { tab:"progresso", showNav:true,  comp:(p)=> <RecuperacaoScreen {...p} /> },
  anamnese:    { tab:"dieta",     showNav:true,  comp:(p)=> <AnamneseScreen {...p} /> },
  kronos:      { tab:"perfil",    showNav:true,  comp:(p)=> <KronosScreen {...p} /> },
  exames:      { tab:"dieta",     showNav:true,  comp:(p)=> <ExamesScreen {...p} /> },
};

/* captions for the gallery */
const ORDER = [
  ["home","01","Home","Saudação, ring de performance, ações rápidas e dica do Kronos"],
  ["treino","02","Treino de Hoje","Treino do dia com séries, reps, kg e RPE por exercício"],
  ["nutricao","03","Nutrição de Hoje","Donut de 2250 kcal, macros e próxima refeição"],
  ["refeicoes","04","Refeições","Abas Todas/Suas/Sugestões com refeições bloqueadas PRO"],
  ["evolucao","05","Evolução","Gráfico de performance +12%, recordes e comparativo de carga"],
  ["recuperacao","06","Recuperação","Prontidão 85%, sono e mapa de grupos musculares"],
  ["anamnese","07","Geração da Dieta","Anamnese: checklist e IA gerando dieta (78%)"],
  ["kronos","08","Kronos","Chat com a IA coach e insights personalizados"],
  ["exames","09","Exames","Upload de PDF/JPG/PNG e histórico de exames"],
  ["splash","10","Splash / Onboarding","Logo, tagline e botões Criar conta / Já tenho conta"],
];

/* one independently-stateful phone (flat, for the contact-sheet grid) */
function Phone({ initial }) {
  const [screen, setScreen] = React.useState(initial);
  const onNav = (id) => setScreen(id);
  const def = SCREENS[screen];
  return (
    <div className="flat-stage">
      <div className="flat-scaler">
        <PhoneShell tab={def.tab} onNav={onNav} showNav={def.showNav} flat={true}>
          <ScreenBody key={screen} render={()=>def.comp({ onNav })} />
        </PhoneShell>
      </div>
    </div>
  );
}
/* tiny wrapper so each screen mounts fresh & resets scroll */
function ScreenBody({ render }) { return render(); }

function Gallery() {
  return (
    <div className="gallery">
      <div className="gallery-head">
        <div className="gallery-eyebrow">KRONOS · O coach que nunca dorme</div>
        <div className="gallery-title">Kronia</div>
        <p className="gallery-sub">
          App de fitness e nutrição com IA clínica — 10 telas hi-fi e interativas. Toque na navegação
          inferior de qualquer aparelho para percorrer o fluxo.
        </p>
      </div>
      <div className="gallery-grid">
        {ORDER.map(([id,n,t,d])=>(
          <div className="phone-cell" key={id}>
            <Phone initial={id} />
            <div className="phone-caption">
              <div className="n">{n}</div>
              <div className="t">{t}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Gallery />);
