/* ============================================================
   KRONIA — Screens 1–5  (Home · Treino · Nutrição · Refeições · Evolução)
   Returns scroll content; PhoneShell + nav applied by app.jsx.
   ============================================================ */

function Thumb({ icon = "apple", size = 52, r = 13 }) {
  return (
    <div className="thumb" style={{ width:size, height:size, borderRadius:r }}>
      <Icon name={icon} size={size*0.42} />
    </div>
  );
}
function FoodThumb({ food, icon, locked = false, size = 52, r = 13 }) {
  const src = food && (typeof window!=='undefined') && window.KRONIA_FOOD && window.KRONIA_FOOD[food];
  if (!src) return (
    <div className="thumb" style={{ width:size, height:size, borderRadius:r, position:"relative" }}>
      <Icon name={locked?"lock":(icon||"apple")} size={size*0.4} />
    </div>
  );
  return (
    <div style={{ width:size, height:size, borderRadius:r, overflow:"hidden", flex:"0 0 auto", position:"relative",
      background:"radial-gradient(120% 120% at 50% 20%, #0c2238, #06121f)", border:"1px solid var(--line)" }}>
      <img src={src} alt="" draggable="false" style={{ width:"100%", height:"100%", objectFit:"cover", filter: locked?"grayscale(0.5) brightness(0.6)":"none" }} />
      {locked && <div style={{ position:"absolute", inset:0, display:"grid", placeItems:"center", background:"rgba(2,8,18,0.4)", color:"#cfe3ff" }}><Icon name="lock" size={size*0.34} /></div>}
    </div>
  );
}
function KLogo({ size = 30 }) {
  const src = (typeof window!=='undefined'&&window.KRONIA_LOGO)||'';
  if (src) return <img src={src} alt="K" draggable="false" style={{ height:size*1.18, width:"auto", filter:"drop-shadow(0 0 9px rgba(0,150,255,0.6))" }} />;
  return (
    <span style={{ fontFamily:"var(--display)", fontWeight:700, fontSize:size, lineHeight:1,
      color:"var(--cyan)", filter:"drop-shadow(0 0 10px rgba(0,194,255,0.6))" }}>K</span>
  );
}

/* ---------------- 1. HOME ---------------- */
function HomeScreen({ onNav }) {
  return (
    <>
      {/* top bar */}
      <div className="pad" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <KLogo size={30} />
          <span style={{ fontFamily:"var(--display)", fontWeight:600, fontSize:18, letterSpacing:"0.24em", color:"#eaf3ff", paddingLeft:"0.12em" }}>KRONIA</span>
        </div>
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          <div style={{ display:"flex", alignItems:"center", gap:7, padding:"6px 11px", borderRadius:999, background:"var(--card)", border:"1px solid var(--line)" }}>
            <span style={{ fontFamily:"var(--display)", fontWeight:700, fontSize:11, letterSpacing:"0.1em", color:"var(--cyan)" }}>FREE</span>
            <span style={{ width:1, height:11, background:"var(--line-strong)" }}></span>
            <span style={{ fontFamily:"var(--display)", fontWeight:600, fontSize:11, color:"var(--muted)" }}>30/15</span>
          </div>
          <button className="iconbtn" onClick={()=>onNav("kronos")}><Icon name="bell" size={18} /><span style={{ position:"absolute", top:10, right:11, width:7, height:7, borderRadius:"50%", background:"var(--cyan)", boxShadow:"0 0 8px var(--cyan)" }}></span></button>
        </div>
      </div>

      {/* greeting + couple (semi-transparent behind) */}
      <div className="pad" style={{ position:"relative", marginBottom:6, minHeight:150 }}>
        <div style={{ position:"absolute", right:-12, top:-26, width:270, pointerEvents:"none",
          WebkitMaskImage:"linear-gradient(90deg, transparent, #000 34%, #000 100%)",
          maskImage:"linear-gradient(90deg, transparent, #000 34%, #000 100%)" }}>
          <div style={{ position:"absolute", inset:"6% 4% 10% 20%", background:"radial-gradient(60% 60% at 55% 45%, rgba(0,120,230,0.30), transparent 72%)", filter:"blur(8px)" }}></div>
          <img src={(typeof window!=='undefined'&&window.KRONIA_COUPLE)||''} alt="" draggable="false"
            style={{ position:"relative", width:"100%", height:"auto", display:"block", opacity:0.5 }} />
        </div>
        <div style={{ maxWidth:200, paddingTop:4, position:"relative" }}>
          <div className="num" style={{ fontSize:30, color:"#fff", lineHeight:1.1 }}>Boa noite,</div>
          <div className="num" style={{ fontSize:30, lineHeight:1.1,
            background:"linear-gradient(90deg,var(--cyan),#5fb8ff)", WebkitBackgroundClip:"text", backgroundClip:"text", WebkitTextFillColor:"transparent" }}>Kleber 👋</div>
          <div style={{ fontSize:13, color:"var(--muted)", marginTop:10, lineHeight:1.5 }}>Seu sistema está em adaptação para máxima performance.</div>
        </div>
      </div>

      {/* performance card */}
      <div className="pad">
        <div className="card glow" style={{ display:"flex", alignItems:"center", gap:8, padding:"18px 14px" }}>
          <div style={{ flex:"0 0 auto", textAlign:"center" }}>
            <div className="eyebrow" style={{ marginBottom:11, letterSpacing:"0.14em", fontSize:10.5, whiteSpace:"nowrap", color:"var(--muted)" }}>Prontidão · auto-declarada</div>
            <Ring size={130} stroke={12} pct={72} value="72" valueSize={34} unit="" sub="" />
            <div style={{ fontSize:11, color:"var(--muted)", marginTop:8, maxWidth:132, marginLeft:"auto", marginRight:"auto", lineHeight:1.4 }}>Calculado da sua fadiga registrada</div>
          </div>
          <div style={{ flex:1, display:"flex", flexDirection:"column", gap:13, paddingLeft:8 }}>
            <StatRow icon="heart" label="Recuperação" value="Boa" />
            <StatRow icon="zap" label="Energia" value="Média-alta" />
            <StatRow icon="activity" label="Fadiga" value="3 / 10" />
            <button onClick={()=>onNav("recuperacao")} style={{ all:"unset", cursor:"pointer", fontSize:11.5, color:"var(--cyan)", fontWeight:600, display:"flex", alignItems:"center", gap:4 }}>Atualizar fadiga <Icon name="chevR" size={13} /></button>
          </div>
        </div>
      </div>

      {/* quick actions */}
      <div className="pad" style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:9, marginTop:14 }}>
        <QuickAction icon="dumbbell" l1="Treino" l2="Hoje" onClick={()=>onNav("treino")} />
        <QuickAction icon="heart" l1="Recuperação" l2="Pronta" onClick={()=>onNav("recuperacao")} />
        <QuickAction icon="apple" l1="Dieta" l2="Alinhada" onClick={()=>onNav("nutricao")} />
        <QuickAction icon="bars" l1="Progresso" l2="Evoluindo" onClick={()=>onNav("evolucao")} />
      </div>

      {/* CTA */}
      <div className="pad" style={{ marginTop:16 }}>
        <button className="btn-cta" onClick={()=>onNav("treino")}>Continuar jornada <Icon name="arrowR" size={18} stroke={2.2} fill="none" /></button>
      </div>
    </>
  );
}
function StatRow({ icon, label, value }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:11 }}>
      <span style={{ flex:"0 0 auto", width:34, height:34, borderRadius:10, display:"grid", placeItems:"center", background:"linear-gradient(150deg,rgba(109,74,254,0.22),rgba(0,194,255,0.12))", border:"1px solid rgba(109,74,254,0.4)", color:"#b9a6ff" }}><Icon name={icon} size={17} /></span>
      <div><div style={{ fontSize:12.5, color:"#dbe9ff", fontWeight:600 }}>{label}</div><div style={{ fontSize:11.5, color:"var(--muted)", marginTop:1 }}>{value}</div></div>
    </div>
  );
}
function QuickAction({ icon, l1, l2, onClick }) {
  return (
    <button onClick={onClick} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:7,
      background:"linear-gradient(180deg,var(--card-2),var(--card))", border:"1px solid var(--line)", borderRadius:15, padding:"13px 4px", cursor:"pointer", color:"#cfe3ff", fontFamily:"var(--body)", transition:".15s" }}
      onMouseEnter={e=>{e.currentTarget.style.borderColor="var(--line-strong)";}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor="var(--line)";}}>
      <span style={{ width:38, height:38, borderRadius:11, display:"grid", placeItems:"center", background:"linear-gradient(150deg,rgba(109,74,254,0.24),rgba(0,194,255,0.12))", border:"1px solid rgba(109,74,254,0.4)", color:"#b9a6ff" }}><Icon name={icon} size={19} /></span>
      <span style={{ fontSize:10.5, fontWeight:600, lineHeight:1.3, textAlign:"center" }}>{l1}<br/><span style={{ color:"var(--muted)", fontWeight:500 }}>{l2}</span></span>
    </button>
  );
}

/* ---------------- 2. TREINO DE HOJE ---------------- */
const EXERCISES = [
  { n:"Supino Reto", d:"4 séries • 6 - 10 reps", kg:"80 kg", rpe:"RPE 7", icon:"dumbbell" },
  { n:"Supino Inclinado", d:"3 séries • 8 - 12 reps", kg:"70 kg", rpe:"RPE 7", icon:"dumbbell" },
  { n:"Crucifixo Máquina", d:"3 séries • 10 - 15 reps", rpe:"RPE 6", chev:true, icon:"activity" },
  { n:"Tríceps Testa", d:"3 séries • 8 - 12 reps", rpe:"RPE 7", chev:true, icon:"zap" },
];
function TreinoScreen({ onNav }) {
  return (
    <>
      <AppBar title="Treino de Hoje" subtitle="Gerado para sua adaptação atual" onBack={()=>onNav("home")} />
      <div className="pad" style={{ position:"relative" }}>
        <div className="card glow" style={{ padding:"16px 16px", marginBottom:18, minHeight:96, display:"flex", alignItems:"center" }}>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:12, color:"var(--muted)" }}>Foco do dia:</div>
            <div className="num" style={{ fontSize:21, color:"#fff", marginTop:5 }}>Força • Peito<br/>• Tríceps</div>
            <div style={{ display:"flex", gap:7, marginTop:11, flexWrap:"wrap" }}><span className="chip"><Icon name="clock" size={12} /> ~52 min</span><span className="chip">{EXERCISES.length} exercícios</span></div>
          </div>
          <div style={{ flex:"0 0 auto", marginRight:-8, marginLeft:-4, alignSelf:"stretch", display:"flex", alignItems:"center" }}>
            <img src={(typeof window!=='undefined'&&window.KRONIA_TREINO)||''} alt="" draggable="false" style={{ height:118, width:"auto", objectFit:"contain", filter:"drop-shadow(0 0 14px rgba(0,150,255,0.35))" }} />
          </div>
        </div>
      </div>

      <div className="pad" style={{ marginBottom:10 }}><div className="num" style={{ fontSize:17, color:"#dbe9ff", letterSpacing:"0.03em" }}>Exercícios</div></div>
      <div className="pad" style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {EXERCISES.map((e,i)=>(
          <div key={i} className="card" style={{ padding:"12px 14px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:13 }}>
              <Thumb icon={e.icon} size={52} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:15, fontWeight:700, color:"#fff" }}>{e.n}</div>
                <div style={{ fontSize:12, color:"var(--muted)", marginTop:3 }}>{e.d}</div>
              </div>
              <div style={{ textAlign:"right", display:"flex", flexDirection:"column", alignItems:"flex-end", gap:3, flex:"0 0 auto", minWidth:54 }}>
                {e.kg && <div className="num" style={{ fontSize:16, color:"var(--cyan)", whiteSpace:"nowrap" }}>{e.kg}</div>}
                <div style={{ fontSize:11, color:"var(--muted)", fontWeight:600, whiteSpace:"nowrap" }}>{e.rpe}</div>
              </div>
            </div>
            <button style={{ marginTop:11, width:"100%", display:"flex", alignItems:"center", justifyContent:"center", gap:7, padding:"9px", borderRadius:10, border:"1px solid var(--line)", background:"var(--card-2)", color:"#bcd8ff", fontFamily:"var(--body)", fontSize:12.5, fontWeight:600, cursor:"pointer" }}
              onMouseEnter={ev=>{ev.currentTarget.style.borderColor="var(--line-strong)";}} onMouseLeave={ev=>{ev.currentTarget.style.borderColor="var(--line)";}}>
              <Icon name="play" size={14} fill="#bcd8ff" stroke={0} /> Ver exercício
            </button>
          </div>
        ))}
      </div>

      <div className="pad" style={{ marginTop:18 }}>
        <button className="btn-cta">Registrar treino <Icon name="arrowR" size={18} stroke={2.2} fill="none" /></button>
      </div>
    </>
  );
}

/* ---------------- 3. NUTRIÇÃO DE HOJE ---------------- */
function NutricaoScreen({ onNav }) {
  return (
    <>
      <AppBar title="Nutrição de Hoje" onBack={()=>onNav("home")} />
      <div className="pad">
        <div className="card glow" style={{ display:"flex", flexDirection:"column", alignItems:"center", padding:"24px 16px 20px" }}>
          <Ring size={184} stroke={15} pct={94} value="2.250" valueSize={42} sub="kcal" />
          <div style={{ fontSize:12.5, color:"var(--muted)", marginTop:6 }}>94% da meta · 2.400 kcal</div>
        </div>
      </div>

      {/* macros */}
      <div className="pad">
        <div className="card">
          <div className="card-hd"><div className="ttl">Macros</div><span className="lnk">Ver detalhes</span></div>
          <div style={{ display:"flex", justifyContent:"space-around" }}>
            <MiniRing pct={92} value="170g" label="Proteínas" />
            <MiniRing pct={87} value="260g" label="Carboidratos" />
            <MiniRing pct={90} value="70g" label="Gorduras" />
          </div>
        </div>
      </div>

      {/* next meal */}
      <div className="pad" style={{ marginTop:16 }}>
        <div className="card-hd" style={{ marginBottom:10 }}><div className="ttl" style={{ fontSize:16 }}>Próxima refeição</div></div>
        <button onClick={()=>onNav("refeicoes")} style={{ all:"unset", cursor:"pointer", display:"block" }}>
          <div className="card" style={{ display:"flex", gap:13, alignItems:"center" }}>
            <FoodThumb food="almoco" size={58} />
            <div style={{ flex:1 }}>
              <div style={{ fontSize:15, fontWeight:700, color:"#fff" }}>Almoço</div>
              <div style={{ fontSize:12.5, color:"var(--muted)", marginTop:3 }}>Frango grelhado + arroz integral</div>
              <div style={{ fontSize:12, color:"var(--cyan)", marginTop:5 }}>em 1h 20m</div>
            </div>
            <Icon name="chevR" size={18} style={{ color:"var(--muted-d)" }} />
          </div>
        </button>
      </div>

      {/* plano */}
      <div className="pad" style={{ marginTop:16 }}>
        <button className="btn-cta" onClick={()=>onNav("refeicoes")}>Ver plano completo <Icon name="arrowR" size={18} stroke={2.2} fill="none" /></button>
      </div>
    </>
  );
}

/* ---------------- 4. REFEIÇÕES ---------------- */
const MEALS = [
  { n:"Café da manhã", kcal:"540", st:"done", food:"cafe", tag:"Sua" },
  { n:"Almoço", kcal:"720", st:"done", food:"almoco", tag:"Sua" },
  { n:"Lanche da tarde", kcal:"320", st:"open", food:"lanche", tag:"Sua" },
  { n:"Jantar", kcal:"620", st:"lock", food:"jantar", tag:"Sugestão" },
  { n:"Ceia", kcal:"300", st:"lock", food:null, icon:"moon", tag:"Sugestão" },
];
function RefeicoesScreen({ onNav }) {
  const [tab, setTab] = React.useState("Todas");
  const list = MEALS.filter(m => tab==="Todas" || (tab==="Suas"&&m.tag==="Sua") || (tab==="Sugestões"&&m.tag==="Sugestão"));
  return (
    <>
      <AppBar title="Refeições" onBack={()=>onNav("nutricao")} />
      <div className="pad"><Tabs tabs={["Todas","Suas","Sugestões"]} active={tab} onChange={setTab} /></div>
      <div className="pad" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginTop:16, marginBottom:6 }}>
        <span style={{ fontSize:13, color:"var(--muted)", fontWeight:500, whiteSpace:"nowrap" }}>Hoje, 17 de maio</span>
        <Icon name="calendar" size={18} style={{ color:"var(--cyan)" }} />
      </div>
      <div className="pad" style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {list.map((m,i)=>(
          <div key={i} className="card" style={{ display:"flex", gap:13, alignItems:"center", padding:"11px 13px" }}>
            <FoodThumb food={m.food} icon={m.icon} locked={m.st==="lock"} size={50} />
            <div style={{ flex:1, minWidth:0, filter: m.st==="lock"?"blur(0.5px)":"none" }}>
              <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                <span style={{ fontSize:14.5, fontWeight:700, color: m.st==="lock"?"var(--muted)":"#fff" }}>{m.n}</span>
                {m.st==="lock" && <span style={{ fontFamily:"var(--display)", fontWeight:700, fontSize:9, letterSpacing:"0.1em", color:"var(--violet)", background:"rgba(109,74,254,0.16)", border:"1px solid rgba(109,74,254,0.4)", borderRadius:5, padding:"2px 6px" }}>PRO</span>}
              </div>
              <div style={{ fontSize:12, color:"var(--muted)", marginTop:3 }}>{m.st==="lock" ? "Desbloqueie com o plano Pro" : m.kcal+" kcal"}</div>
            </div>
            {m.st==="done" && <span style={{ width:30, height:30, borderRadius:"50%", display:"grid", placeItems:"center", background:"rgba(47,227,154,0.14)", border:"1px solid rgba(47,227,154,0.4)", color:"var(--good)" }}><Icon name="check" size={16} stroke={2.6} /></span>}
            {m.st==="open" && <Icon name="chevR" size={18} style={{ color:"var(--cyan)" }} />}
            {m.st==="lock" && <Icon name="lock" size={17} style={{ color:"var(--violet)" }} />}
          </div>
        ))}
      </div>
      <div className="pad" style={{ marginTop:18 }}>
        <button className="btn-cta"><Icon name="plus" size={18} stroke={2.4} /> Registrar refeição</button>
      </div>
    </>
  );
}

/* ---------------- 5. EVOLUÇÃO ---------------- */
function EvolucaoScreen({ onNav }) {
  const [tab, setTab] = React.useState("Visão geral");
  const [hasData, setHasData] = React.useState(false);
  const pts = [18,30,24,44,52,46,68,60,82,76,92,84];
  const max = 110, w=288, h=110;
  const path = pts.map((p,i)=>`${(i/(pts.length-1))*w},${h-(p/max)*h}`).join(" ");
  const dates = ["11/05","12/05","13/05","14/05","15/05","16/05","17/05"];
  return (
    <>
      <div className="pad" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
        <div className="num" style={{ fontSize:24, color:"#fff" }}>Evolução</div>
        <span className="chip">Esta semana <Icon name="chevD" size={13} /></span>
      </div>
      <div className="pad"><Tabs tabs={["Visão geral","Força","Carga","Hábitos"]} active={tab} onChange={setTab} /></div>

      {!hasData ? (
        /* ---- empty state ---- */
        <div className="pad" style={{ marginTop:14 }}>
          <div className="card" style={{ textAlign:"center", padding:"34px 22px" }}>
            <div style={{ position:"relative", width:120, height:78, margin:"0 auto 20px" }}>
              <svg viewBox="0 0 120 78" width="120" height="78" style={{ position:"relative", zIndex:1 }}>
                <line x1="10" y1="64" x2="112" y2="64" stroke="var(--line-strong)" strokeWidth="1.5" />
                <line x1="10" y1="6" x2="10" y2="64" stroke="var(--line-strong)" strokeWidth="1.5" />
                <polyline points="22,50 48,52 74,40 98,42" fill="none" stroke="var(--muted-d)" strokeWidth="2" strokeDasharray="4 5" strokeLinecap="round" />
                <circle cx="22" cy="50" r="4" fill="var(--cyan)" />
                <circle cx="98" cy="42" r="4" fill="var(--violet)" />
              </svg>
            </div>
            <div className="num" style={{ fontSize:19, color:"#fff" }}>Sem dados ainda</div>
            <div style={{ fontSize:13, color:"var(--muted)", marginTop:8, lineHeight:1.5, maxWidth:250, marginLeft:"auto", marginRight:"auto" }}>
              Registre <b style={{color:"#dbe9ff"}}>2 ou mais medidas</b> (peso ou carga) para o KRONOS traçar sua evolução.
            </div>
            <div style={{ marginTop:20 }}>
              <button className="btn-cta" onClick={()=>setHasData(true)}><Icon name="plus" size={17} stroke={2.4} /> Registrar agora</button>
            </div>
            <button onClick={()=>setHasData(true)} style={{ all:"unset", cursor:"pointer", marginTop:13, fontSize:12, color:"var(--cyan)", fontWeight:600 }}>Ver exemplo com dados →</button>
          </div>

          <div className="card" style={{ marginTop:12, display:"flex", gap:13, alignItems:"center", padding:"14px" }}>
            <span style={{ flex:"0 0 auto", width:40, height:40, borderRadius:11, display:"grid", placeItems:"center", background:"var(--blue-soft)", border:"1px solid var(--line)", color:"var(--cyan)" }}><Icon name="ruler" size={20} /></span>
            <div style={{ flex:1 }}><div style={{ fontSize:13.5, fontWeight:700, color:"#fff" }}>Primeira medida</div><div style={{ fontSize:12, color:"var(--muted)", marginTop:2 }}>Peso, cintura ou foto de progresso</div></div>
            <Icon name="chevR" size={17} style={{ color:"var(--muted-d)" }} />
          </div>
        </div>
      ) : (
        /* ---- populated ---- */
        <>
          <div className="pad" style={{ marginTop:14 }}>
            <div className="card" style={{ padding:"16px 14px 12px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                <span style={{ fontSize:13.5, color:"#dbe9ff", fontWeight:600 }}>Evolução de carga</span>
                <span className="num" style={{ fontSize:16, color:"var(--good)" }}>+12%</span>
              </div>
              <div style={{ display:"flex", gap:8 }}>
                <div style={{ display:"flex", flexDirection:"column", justifyContent:"space-between", paddingBottom:18, fontSize:9.5, color:"var(--muted-d)", fontFamily:"var(--display)" }}>
                  <span>120</span><span>90</span><span>60</span><span>30</span>
                </div>
                <div style={{ flex:1 }}>
                  <svg viewBox={`0 -6 ${w} ${h+12}`} width="100%" height={h} style={{ overflow:"visible" }}>
                    <defs>
                      <linearGradient id="evoFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="rgba(0,194,255,0.28)" /><stop offset="100%" stopColor="rgba(0,194,255,0)" /></linearGradient>
                      <linearGradient id="evoStroke" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="var(--cyan)" /><stop offset="100%" stopColor="var(--violet)" /></linearGradient>
                    </defs>
                    {[0.25,0.5,0.75,1].map((g,i)=>(<line key={i} x1="0" y1={h*g} x2={w} y2={h*g} stroke="rgba(40,90,150,0.16)" strokeWidth="1" />))}
                    <polyline points={`0,${h} ${path} ${w},${h}`} fill="url(#evoFill)" stroke="none" />
                    <polyline points={path} fill="none" stroke="url(#evoStroke)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    {pts.map((p,i)=> i%2===0 && <circle key={i} cx={(i/(pts.length-1))*w} cy={h-(p/max)*h} r="3" fill="var(--cyan)" />)}
                  </svg>
                  <div style={{ display:"flex", justifyContent:"space-between", marginTop:6, fontSize:8.5, color:"var(--muted-d)", fontFamily:"var(--display)" }}>
                    {dates.map(d=><span key={d}>{d}</span>)}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pad" style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:9, marginTop:14 }}>
            {[["3","Recordes"],["6","Treinos"],["87%","Consist."],["21","Streak",true]].map((r,i)=>(
              <div key={i} className="card" style={{ textAlign:"center", padding:"14px 4px" }}>
                <div className="num" style={{ fontSize:23, color:"#fff" }}>{r[0]}</div>
                <div style={{ fontSize:10, color:"var(--muted)", marginTop:4 }}>{r[1]}{r[2] && <span style={{display:"block",fontSize:9,color:"var(--muted-d)"}}>dias</span>}</div>
              </div>
            ))}
          </div>

          <div className="pad" style={{ marginTop:16 }}>
            <div className="card">
              <div className="card-hd"><div className="ttl">Comparação</div><span className="chip" style={{ fontSize:10 }}>Semana passada <Icon name="chevD" size={11} /></span></div>
              <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
                <div><div style={{ fontSize:11, color:"var(--muted)", marginBottom:6 }}>Esta semana</div><div className="pgbar" style={{height:10}}><i style={{ width:"88%" }}></i></div></div>
                <div><div style={{ fontSize:11, color:"var(--muted-d)", marginBottom:6 }}>Semana passada</div><div className="pgbar" style={{height:10}}><i style={{ width:"64%", background:"rgba(40,90,150,0.5)" }}></i></div></div>
              </div>
              <div style={{ textAlign:"right", marginTop:10 }}><span className="chip good"><Icon name="trending" size={12} /> Está acima</span></div>
            </div>
          </div>
          <div className="pad" style={{ marginTop:14 }}>
            <button onClick={()=>setHasData(false)} style={{ all:"unset", cursor:"pointer", display:"block", textAlign:"center", width:"100%", fontSize:12, color:"var(--muted-d)", fontWeight:600 }}>← Voltar ao estado vazio</button>
          </div>
        </>
      )}
    </>
  );
}

Object.assign(window, { HomeScreen, TreinoScreen, NutricaoScreen, RefeicoesScreen, EvolucaoScreen, Thumb, KLogo });
