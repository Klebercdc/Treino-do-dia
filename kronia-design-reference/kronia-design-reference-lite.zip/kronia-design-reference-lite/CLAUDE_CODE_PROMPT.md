# CLAUDE CODE — REPLICAÇÃO VISUAL + AUDITORIA FUNCIONAL

Objetivo: replicar fielmente o estilo visual dos arquivos em `kronia-design-reference-lite/source/` nas telas reais existentes do KRONIA.

Obrigatório:
- manter funcionalidades reais;
- manter botões funcionando;
- auditar navegação, modais, rotas, estados, responsividade;
- não adicionar telas/features extras;
- não transformar em layout clean genérico;
- preservar o uso visual dos corpos/estruturas 3D conforme referência.

Critério de aceite: visual novo aplicado + fluxos funcionais.
