# KRONIA Design Reference Lite

Versão leve da referência visual para subir no GitHub abaixo de 25 MB.

Use `source/` como fonte visual principal para replicar o estilo no app real.

Não criar novo app. Não adicionar funcionalidades. Adaptar o estilo às telas existentes e auditar botões/fluxos.
